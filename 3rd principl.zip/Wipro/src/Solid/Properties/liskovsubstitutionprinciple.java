package Solid.Properties;

public class liskovsubstitutionprinciple {

}
class Bird {
    public void makeSound() {
        System.out.println("Bird makes sound");
    }
}

class Duck extends Bird {
    @Override
    public void makeSound() {
        System.out.println("Duck quacks");
    }
}

class Sparrow extends Bird {
    @Override
    public void makeSound() {
        System.out.println("Sparrow chirps");
    }
    public static void main(String[] args) {
        Bird duck = new Duck();
        Bird sparrow = new Sparrow();

        duck.makeSound();   // Output: Duck quacks
        sparrow.makeSound(); // Output: Sparrow chirps
    }
}


